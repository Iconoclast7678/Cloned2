(This README.md is WIP)

![logo](https://cdn.discordapp.com/attachments/711793583677767750/812202572253233172/Cloned_Dribes_Logos.png)
# Cloned Drives - possibly the most complex Discord game bot to exist

For the first time in history, you can race any kind of vehicle you wish on all sorts of tracks... on Discord.

# What is Cloned Drives?

Cloned Drives is a Discord game bot that is based on a mobile game called Top Drives, which is made by Hutch Games Ltd. 

# How does it work?

Basically how it works is there are a bunch of cars in the form of cards that you can collect, upgrade and "race". You get these 5 cars in your infinitely-sized garage when you start off:

- The 1999 Honda S2000, pretty much everyone knows this one heck of a sports car
- The 1989 Peugeot 405 Mi16, it's a sporty French sedan with sharp looks
- The 1989 Range Rover County, a trusty machine for off-roading
- The 2010 Nissan Leaf, yes it's a boring pick but it serves you well for mundane tasks
- The 1967 De Tomaso Mangusta (US-spec), the relatively obscure Italian classic

# Important Mechanics

## Handling

Handling is 

## RQ

RQ (Race Quota in short, derived from Top Drives) is the unit of measurement for a car's overall racing ability. It takes a lot of variables into account, including top speed, acceleration

# Credits
Bnuuy, Andu, Connor, Ploosh + 20 other people - graphics & cars  
Keanny - everything else